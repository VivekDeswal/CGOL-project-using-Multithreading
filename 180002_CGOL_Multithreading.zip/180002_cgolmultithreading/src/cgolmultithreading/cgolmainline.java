package cgolmultithreading;

import java.util.Scanner;

/**
 * 
 * Description : Project is all about the CGOL program using 
 * Multithreading
 * 
 * @author Vivek Deswal 
 * 
 * @version 1.0 
 *
 */

public class cgolmainline {
	public static void main(String []args) {
	int i,j,k,l;
	String nextlife;
    Scanner scan= new Scanner(System.in);
    
	System.out.println("Enter the elements of array containing 0 and 1");
	System.out.println("Enter the size of matrix for CGOL");
	
	// for scanning the length of row and column
	k= scan.nextInt();
	l=scan.nextInt();
	
	System.out.println("Size of CGOL matrix is: "+k+"*"+l);
	
	int arr[][] = new int[k][l];
	//for scanning of array
	for(i=0;i<k;i++) {
		for(j=0;j<l;j++) {
			   arr[i][j] = scan.nextInt();
		}
	}
	
	// for printing Stage 1 of Cgol 
	System.out.println("Stage 1");
	for(i=0;i<k;i++) {
		for(j=0;j<l;j++) {
			System.out.print(arr[i][j]+" ");
		}
		System.out.println();
		
	}
	// calling of function from different class
	do {
		Cgollogic lg = new Cgollogic(k,l,arr);
		lg.start();
		nextlife = scan.next();
	   } while (nextlife.equals("yes"));
	System.out.println("Game over");

	scan.close();
	}}